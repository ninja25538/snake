xss.bootstrap.server = function() {
    xss.shapegen = new xss.ShapeGenerator();
    xss.transform = new xss.Transform();
};
