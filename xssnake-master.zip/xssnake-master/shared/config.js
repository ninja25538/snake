'use strict';

xss.SERVER_HOST = '127.0.0.1';
xss.SERVER_PORT = 8001;
xss.SERVER_PATH = '';
xss.SERVER_ENDPOINT = xss.SERVER_HOST + ':' + xss.SERVER_PORT + xss.SERVER_PATH;
