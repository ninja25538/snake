'use strict';

/**
 * @param {xss.Coordinate} location
 * @param {number} direction
 * @constructor
 */
xss.level.Spawn = function(location, direction) {
    this.location = location;
    this.direction = direction;
};

xss.level.Spawn.prototype = {

};
