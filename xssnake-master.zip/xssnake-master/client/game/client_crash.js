'use strict';

/**
 * @param {xss.Coordinate=} part
 * @constructor
 */
xss.ClientCrash = function(part) {
    this.location = part;
};
