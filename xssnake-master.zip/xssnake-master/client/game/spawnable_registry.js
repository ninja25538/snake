'use strict';

/**
 * @constructor
 */
xss.game.SpawnableRegistry = function(){};

xss.game.SpawnableRegistry.prototype = {
    destruct: function() {

    }
};
