'use strict';
var xss = {};
